
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    if data['email'] == 'admin@example.com' and data['password'] == 'admin':
        return jsonify({'token': 'mock_token', 'role': 'admin'})
    return jsonify({'message': 'Invalid credentials'}), 401

if __name__ == '__main__':
    app.run(debug=True)
